﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace realtor
{
    public partial class Domzap : Form
    {
        public Domzap()
        {
            InitializeComponent();
        }
    }
}
