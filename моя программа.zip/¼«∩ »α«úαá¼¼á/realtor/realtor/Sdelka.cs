﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace realtor
{
    public partial class Sdelka : Form
    {
        public Sdelka()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sdelkazap sdzap = new Sdelkazap();
            sdzap.Show();
        }
    }
}
